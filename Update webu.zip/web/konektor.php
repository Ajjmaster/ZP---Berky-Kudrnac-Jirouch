<?php
$db_server = 'localhost'; /* N�zev serveru, ke kter�mu se budeme p�ipojovat */
$db_login = 'root'; /* Jm�no u�ivatele do DB */
$db_password = 'Kolecko123'; /* Heslo u�ivatele do DB */
$db_name = 'liberprimus'; /* N�zev datab�ze, ve kter� jsme si vytvo�ili tabulku "uzivatele" */
$spojeni = @MySQL_Connect($db_server ,$db_login, $db_password);
@MySQL_Select_DB($db_name)or die('<p style="color: red">Nastala chyba v pripojeni k databazi');
mysql_query("set names utf8");
?>