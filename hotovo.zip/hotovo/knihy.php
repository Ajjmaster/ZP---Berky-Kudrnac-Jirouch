<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta name="generator" content="PSPad editor, www.pspad.com">
  <link rel="stylesheet" href="style.css">
  <title>pcpodpora</title>
  </head>
  
<header>
  <h2>Liber Primus</h2>
</header>
    
    <body>
    
  
<section>
  <nav>
    <ul>
      <li><a href="index.html">Hlavní stránka</a></li>
       <br>
      <li><a href="knihy.php">Knihy</a></li>
       <br>
      <li><a href="spisovatele.php">Spisovatelé</a></li>
        <br>
      <li><a href="onas.html">O nás</a></li>
        <br>
      <li><a href="prihlasitse.php">Příhlásit se</a></li>
        <br>
      <li><a href="registrovatse.php">Registrovat se</a></li>
    </ul>
  </nav>
    
</section>
 <tr>
 <td><input type="text" id="vyhledat" value="" size="17" tabindex="2" placeholder="Vyhledat" /></td>
 </tr><section> 
   <form method= "post">             <select name="vyber">
  <option value="1" selected >Relativně</option>
  <option value="2">A-Z</option>
  <option value="3">Z-A</option>
  <option value="4">Podle spisovatele A-Z</option>
  <option value="5">Podle spisovatele Z-A</option>
    <input type="submit" name="submit">
    
</select> </form> 
    <article>
    <div class = "polozky">
        <div class = "polozka"><img src = "otaznik.png" height = 200 width = 200 ></div>
        <div class = "polozka"><img src = "otaznik.png" height = 200 width = 200 ></div>
        <div class = "polozka"><img src = "otaznik.png" height = 200 width = 200 ></div>
        <div class = "polozka"><img src = "otaznik.png" height = 200 width = 200 ></div>
        <div class = "polozka"><img src = "otaznik.png" height = 200 width = 200 ></div>
        <div class = "polozka"><img src = "otaznik.png" height = 200 width = 200 ></div>
        <div class = "polozka"><img src = "otaznik.png" height = 200 width = 200 ></div>
        <div class = "polozka"><img src = "otaznik.png" height = 200 width = 200 ></div>
        <div class = "polozka"><img src = "otaznik.png" height = 200 width = 200 ></div>    
        <div class = "polozka"><img src = "otaznik.png" height = 200 width = 200 ></div>    
        </div>
  </article>
    

 <?php 
      include "konektor.php";
                 if (isset($_GET['vyber'])) {
      $vyber = $_GET["vyber"];
           if($vyber == 1){  $sql = "SELECT nazev FROM titul;";}
            if($vyber == 2){ $sql ="SELECT nazev, autor FROM titul  ORDER BY nazev ASC"; } 
            if($vyber == 3){ $sql ="SELECT nazev, autor FROM titul   ORDER BY nazev DESC;";} 
            if($vyber == 4){ $sql ="SELECT nazev, autor FROM titul  ORDER BY autor asc;"; } 
            if($vyber == 5){ $sql ="SELECT nazev, autor FROM titul  ORDER BY autor  DESC;"; }   
        
              
        $result = $conn->query($sql);  
        $result->setFetchMode(PDO::FETCH_ASSOC); 
      ?> 
        <table>
        <?php while ($row = $result->fetch()): ?>        
         <tr>
          <td><?php echo $row['autor'];?></td>
          <td><?php echo $row['nazev'];?></td>
         </tr>        
        <?php endwhile; }   
         ?>     
         
            
        </table> ?>
      </section> 
  </body>
    
    <footer>
  <p>Autor: Matyáš Berky, Jirouch, Kudrnáč</p>
</footer> 
 </html>