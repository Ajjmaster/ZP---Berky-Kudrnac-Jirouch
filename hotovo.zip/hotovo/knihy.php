<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta name="generator" content="PSPad editor, www.pspad.com">
  <link rel="stylesheet" href="style.css">
  <title>pcpodpora</title>
  </head>
  
<header>
  <h2>Liber Primus</h2>
</header>
    
    <body>
  
<section>
  <nav>
    <ul>
      <li><a href="index.html">Hlavní stránka</a></li>
       <br>
      <li><a href="knihy.php">Knihy</a></li>
       <br>
      <li><a href="spisovatele.php">Spisovatelé</a></li>
        <br>
      <li><a href="onas.html">O nás</a></li>
        <br>
      <li><a href="prihlasitse.php">Příhlásit se</a></li>
        <br>
      <li><a href="registrovatse.php">Registrovat se</a></li>
    </ul>
  </nav>
    
</section>
 <?php 
  include "konektor.php";
        $sql = "SELECT nazev, autor, fypocet FROM titul ASC;;";
              
        $result = $conn->query($sql);  
        $result->setFetchMode(PDO::FETCH_ASSOC);
      ?> 
        <table>
        <?php while ($row = $result->fetch()): ?>        
         <tr>
          <td><?php echo $row['nazev'];?></td>
          <td><?php echo $row['autor'];?></td>
          <td><?php echo $row['fypocet'];?></td>
          
         </tr>        
        <?php endwhile; ?> 
        </table>?>
       
  </body>
    
    <footer>
  <p>Autor: Matyáš Berky, Jirouch, Kudrnáč</p>
</footer>
    
</html>