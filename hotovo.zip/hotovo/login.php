<?php
session_start();
include "./konektor.php";/* p�ipojen� k datab�zi */
$login = mysql_real_escape_string($_POST["email"]);/* nick zadan� ve formul��i pro p�ihla�ov�n� */
$heslo = mysql_real_escape_string($_POST["heslo"]);/* heslo zadan� ve formul��i pro p�ihla�ov�n� */
$md5heslo = md5($heslo);/* Pomoc� funkce md5() heslo zahashujeme */
/* � SQL DOTAZ PRO OV��EN� PRAVOSTI P�IHLA�OVAC�H DAT V DATAB�ZI A U�IVATELEM ZADAN�CH � */
$dotaz = mysql_query("select * from uzivatele where login = '$login' and heslo = '$md5heslo'");
$overeni = mysql_num_rows($dotaz);
$row = mysql_fetch_array($dotaz);
if($overeni == 1) {
 session_start();
 $_SESSION['login'] = stripslashes($login); 
/* Zde se vytv��� SESSION 'login', kterou se budeme prokazovat jako p�ihl�en� */
 $_SESSION['id'] = $row["id"];
 $_SESSION['role'] = $row["idrole"];
 $_SESSION['jmeno'] = $row["email"];
 header("Location: index.thml"); /* V p��pad� spr�vn�ho p�ihl�en� se p�esm�ruje na admin.php */
} else {
 echo"Zadal jsi �patn� email nebo heslo!";
}   
 if($_SESSION['login'] = true){
    echo "uzivatel $_SESSION['jmeno'] je p�ihl�en " 
 } else {echo "u�ivatel nep�ihl�en";}
?>
