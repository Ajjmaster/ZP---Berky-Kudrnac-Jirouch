<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta name="generator" content="PSPad editor, www.pspad.com">
  <link rel="stylesheet" href="style.css">
  <title>pcpodpora</title>
  </head>
  
<header>
  <h2>Liber Primus</h2>
</header>
    
    <body>
  
<section>
  <nav>
    <ul>
      <li><a href="index.html">Hlavní stránka</a></li>
       <br>
      <li><a href="knihy.php">Knihy</a></li>
       <br>
      <li><a href="spisovatele.php">Spisovatelé</a></li>
        <br>
      <li><a href="onas.html">O nás</a></li>
        <br>
      <li><a href="prihlasitse.php">Příhlásit se</a></li>
        <br>
      <li><a href="registrovatse.php">Registrovat se</a></li>
    </ul>
  </nav>
    
</section>  
           <form action="login.php" method="post"> 
 <table>
 <tr>
 <td>Přezdívka: </td>
 <td><input type="text" name="jmeno" value="" size="17" tabindex="1" /></td>
 </tr>
 <tr>
 <td>Heslo: </td>
 <td><input type="password" name="heslo" value="" size="17" tabindex="2" /></td>
 </tr>
 <tr>
 <td colspan="2"><input type="submit" name="submit" value="Přihlásit se" /></td>
 </tr>
 <tr>
 <td colspan="2" align="right">Pokud nemáte účet, <a href="/registrovatse.php">registrujte se</a></td>
 </tr>
 </table>
 </form>
		</main>
	</section>
  </body>
    
    <footer>
  <p>Autor: Matyáš Berky, Jirouch, Kudrnáč</p>
</footer>
    
</html>