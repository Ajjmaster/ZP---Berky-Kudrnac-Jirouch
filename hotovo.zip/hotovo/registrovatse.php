<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta name="generator" content="PSPad editor, www.pspad.com">
  <link rel="stylesheet" href="style.css">
  <title>pcpodpora</title>
  </head>
  
<header>
  <h2>Liber Primus</h2>
</header>
    
    <body>
  
<section>
  <nav>
    <ul>
      <li><a href="index.html">Hlavní stránka</a></li>
       <br>
      <li><a href="knihy.php">Knihy</a></li>
       <br>
      <li><a href="spisovatele.php">Spisovatelé</a></li>
        <br>
      <li><a href="onas.html">O nás</a></li>
        <br>
      <li><a href="prihlasitse.php">Příhlásit se</a></li>
        <br>
      <li><a href="registrovatse.php">Registrovat se</a></li>
    </ul>
  </nav>
    
</section>
     <?php
include "konektor.php";
if(isset($_POST['submit'])) {
 $nick = mysql_real_escape_string($_POST['nick']);
 $heslo = mysql_real_escape_string($_POST['heslo']);
 $over_heslo = mysql_real_escape_string($_POST['over_heslo']);
 $md5_heslo = md5($heslo);
 $email = mysql_real_escape_string($_POST['email']);
 
 $user_check = mysql_query("SELECT login FROM uzivatele WHERE login='".$nick."'");
 if($nick==""){echo"Nebyl vyplněn nick!";}
 else if(mysql_num_rows($user_check)){echo"Tento nick používá již jiný uživatel.";}
 else if($heslo==""){echo"Nebylo vyplněno heslo";}
 else if($over_heslo==""){echo"Nebylo vyplněno ověřovací heslo";}
 else if($heslo!=$over_heslo){echo"Vyplněná hesla se neshodují";}
 else if($email==""){echo"Nebyl vyplněn email";}
 else{
 $sql= mysql_query("INSERT INTO uzivatele VALUES ('','$nick','$md5_heslo','$email')") or die(mysql_error());
 echo"Registrace byla úspěšně dokončena!";
 }
}
?>
	
	
  </body>
    
    <footer>
  <p>Autor: Matyáš Berky, Jirouch, Kudrnáč</p>
</footer>
    
</html>