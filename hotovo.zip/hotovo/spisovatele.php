<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta name="generator" content="PSPad editor, www.pspad.com">
  <link rel="stylesheet" href="style.css">
  <title>pcpodpora</title>
  </head>
  
<header>
  <h2>Liber Primus</h2>
</header>
    
    <body>
   
       <input type="text" name=vyhledat placeholder="vyhledávání" value="">
<section>
  <nav>
    <ul>
      <li><a href="index.html">Hlavní stránka</a></li>
       <br>
      <li><a href="knihy.php">Knihy</a></li>
       <br>
      <li><a href="spisovatele.php">Spisovatelé</a></li>
        <br>
      <li><a href="onas.html">O nás</a></li>
        <br>
      <li><a href="prihlasitse.php">Příhlásit se</a></li>
        <br>
      <li><a href="registrovatse.php">Registrovat se</a></li>
    </ul>
  </nav>
    
</section>
         <select name="vyber">
  <option value="1" selected >Relativně</option>
  <option value="2">A-Z</option>
  <option value="3">Z-A</option>
  
</select> 
        
      <?php 
      include "konektor.php";
        if (isset($_GET['vyber'])) {
           $vyber=$_GET['vyber'];
           if($vyber == 1){   $sql = "SELECT UNIQUE autor FROM titul;";
           }else if($vyber == 2){   $sql = "SELECT UNIQUE autor FROM titul  ORDER BY autor ASC";
           }else if($vyber == 3){   $sql = "SELECT UNIQUE autor FROM titul  ORDER BY autor DESC;";
           }
        
              
        $result = $conn->query($sql);  
        $result->setFetchMode(PDO::FETCH_ASSOC);
      ?> 
        <table>
        <?php while ($row = $result->fetch()): ?>        
         <tr>
          <td><?php echo $row['autor'];?></td>
          
         </tr>        
        <?php endwhile;} ?> 
        </table>?>
  </body>
    
    <footer>
  <p>Autor: Matyáš Berky, Jirouch, Kudrnáč</p>
</footer>
    
</html>