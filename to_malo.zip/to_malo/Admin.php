<?php
session_start(); 
?>
</head>
<body>
<h2>TEXT PRO V�ECHNY U�IVATELE (p�ihl�en�+nep�ihl�en�)</h2> 
<?php
 if($_SESSION['login']!=""){
 echo'TEXT POUZE PRO P�IHL��EN� U�IVATELE - JSI V�T�N!!!<br> 
 <a href="/logout.php">Odhl�sit se</a>'; 
 } else {
 echo'TEXT PRO NEP�IHL��EN� U�IVATELE - Tato str�nka je p��stupn� pouze p�ihl�en�m u�ivatel�m. Pokud nem� ��et, <a href="/registrace.php">zaregistruj se</a>!<br> /* Text pro nep�ihl�en� */
 <h2>P�ihl�sit se:</h2>
 <form action="login.php" method="post"> 
 <table>
 <tr>
 <td>P�ezd�vka: </td>
 <td><input type="text" name="nick" value="" size="17" tabindex="1" /></td>
 </tr>
 <tr>
 <td>Heslo: </td>
 <td><input type="password" name="heslo" value="" size="17" tabindex="2" /></td>
 </tr>
 <tr>
 <td colspan="2"><input type="submit" name="submit" value="P�ihl�sit se" /></td>
 </tr>
 </table>
 </form>';
 }
?>