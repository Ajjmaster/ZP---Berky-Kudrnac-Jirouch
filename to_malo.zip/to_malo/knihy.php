<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta name="generator" content="PSPad editor, www.pspad.com">
  <link rel="stylesheet" href="style.css">
      <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
  <title>LiberPrimus</title>
  </head>
   
    <body>
        
        <div class="header">
        
            <div class="inner_header">
               
                <div class="logo">
                <h1>Liber<span>Primus</span></h1>
                </div>
                
             <ul class="menu">
                 <a class="kategorie" href="index.html"><li>Hlavní stránka</li></a>
                 <a class="kategorie" href="knihy.php"><li>Knihy</li></a>
                 <a class="kategorie" href="onas.html"><li>O nás</li></a>
                 <a class="kategorie" href="prihlasitse.html"><li>Přihlásit se</li></a>
                 <a class="kategorie" href="registrovatse.php"><li>Registrace</li></a>
                 
                 
            </ul>
             
                
          </div>
       
        </div>
  
<section> 
   
    
</section>
    
  </body>
        <?php 
      include "konektor.php";
                 if (isset($_GET['vyber'])) {
      $vyber = $_GET["vyber"];
           if($vyber == 1){  $sql = "SELECT nazev FROM titul;";}
            if($vyber == 2){ $sql ="SELECT nazev, autor, fypocet FROM titul  ORDER BY nazev ASC;"; } 
            if($vyber == 3){ $sql ="SELECT nazev, autor, fypocet FROM titul   ORDER BY nazev DESC;";} 
            if($vyber == 4){ $sql ="SELECT nazev, autor, fypocet FROM titul  ORDER BY autor asc;"; } 
            if($vyber == 5){ $sql ="SELECT nazev, autor, fypocet FROM titul  ORDER BY autor  DESC;"; }   
            
        $result = $conn->query($sql);  
        $row = $result->rowCount();
        $row1 = $result->fetchAll();
        print_r($row1[$i]['titul']);
      ?> 
        <table>
        <?php while ($row = $result->fetch()): ?>        
         <tr>
          <td><?php echo $row['autor'];?></td>
          <td><?php echo $row['nazev'];?></td>
          <td><?php echo $row['fypocet'];?></td>
         </tr>        
        <?php endwhile; }   
         ?>     
         
    <footer>
  <p>Autor: Matyáš Berky, Jirouch, Kudrnáč</p>
</footer>
    
</html>