<?php
session_start();
include "./konektor.php";
$login = mysql_real_escape_string($_POST["email"]);
$heslo = mysql_real_escape_string($_POST["heslo"]);
$md5heslo = md5($heslo);
$dotaz = mysql_query("select * from uzivatele where login = '$login' and heslo = '$md5heslo'");
$overeni = mysql_num_rows($dotaz);
$row = mysql_fetch_array($dotaz);
if($overeni == 1) {
 session_start();
 $_SESSION['login'] = stripslashes($login); 

 $_SESSION['id'] = $row["id"];
 $_SESSION['role'] = $row["idrole"];
 $_SESSION['jmeno'] = $row["email"];
 header("Location: index.html"); 
} else {
 echo"Zadal jsi �patn� email nebo heslo!";
}   
 if($_SESSION['login'] = true){
    echo "uzivatel ".$_SESSION['jmeno']'." je p�ihl�en ";
 } else {echo "u�ivatel nep�ihl�en";}
?>
