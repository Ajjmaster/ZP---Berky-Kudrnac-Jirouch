<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta name="generator" content="PSPad editor, www.pspad.com">
  <link rel="stylesheet" href="style.css">
      <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
  <title>LiberPrimus</title>
  </head>
             <link href=admin.php>
             
    <body>
        
         <div class="header">
        
            <div class="inner_header">
               
                <div class="logo">
                <h1>Liber<span>Primus</span></h1>
                </div>
             <ul class="menu">
                 <a class="kategorie" href="index.html"><li>Hlavní stránka</li></a>
                 <a class="kategorie" href="knihy.php"><li>Knihy</li></a>
                 <a class="kategorie" href="onas.html"><li>O nás</li></a>
                 <a class="kategorie" href="prihlasitse.php"><li>Přihlásit se</li></a>
                 <a class="kategorie" href="registrovatse.html"><li>Registrace</li></a>
                 
                 
            </ul>
             
                
          </div>
       
        </div>
  
<section>
      	<?php
include "konektor.php";
if(isset($_POST['submit'])) {
 $jmeno = mysql_real_escape_string($_POST['jmeno']);
 $prijmeni = mysql_real_escape_string($_POST['prijmeni']);
 $tel = mysql_real_escape_string($_POST['tel']);
 $heslo1 = mysql_real_escape_string($_POST['heslo']);
 $over_heslo = mysql_real_escape_string($_POST['over_heslo']);
 $heslo = md5($heslo1);
 $email = mysql_real_escape_string($_POST['email']);
 
 $user_check = mysql_query("SELECT login FROM uzivatele WHERE login='".$email."'");
 if($email==""){echo"Nebyl vyplněn email!";}
 else if(mysql_num_rows($user_check)){echo"Tento email již byl použit.";}
 else if($heslo1==""){echo"Nebylo vyplněno heslo";}
 else if($over_heslo==""){echo"Nebylo vyplněno ověřovací heslo";}
 else if($heslo1!=$over_heslo){echo"Vyplněná hesla se neshodují";}
 else if($email==""){echo"Nebyl vyplněn email";}
 else{
 $sql= mysql_query("INSERT INTO uzivatele VALUES ('','$jmeno','$prijmeni','$heslo','$email')") or die(mysql_error());
 echo"Registrace byla úspěšně dokončena!";
 }
}
?>  
<form action="index.html" method="post"> 
<table> 
<tr> <td>Jméno: </td> <td><input type="text" name="jmeno" value="" size="25" tabindex="1" placeholder=""/></td> </tr>
<tr> <td>Příjmení: </td> <td><input type="text" name="prijmeni" value="" size="25" tabindex="1" /></td> </tr>
<tr> <td>Heslo: </td> <td><input type="password" name="heslo1" value="" size="25" tabindex="2" /></td> </tr> 
<tr> <td>Ověření hesla: </td> <td><input type="password" name="over_heslo" value="" size="25" tabindex="3" /></td> </tr> 
<tr> <td>Email: </td> <td><input type="text" name="email" value="" size="25" tabindex="4" /></td> </tr> 
<tr> <td colspan="2"><input type="submit" name="submit" value="Registrovat se" /></td> </tr> 
</table> 
</form>        
</section>

  </body>
    
    <footer>
  <p>Autor: Matyáš Berky, Jirouch, Kudrnáč</p>
</footer>
    
</html>